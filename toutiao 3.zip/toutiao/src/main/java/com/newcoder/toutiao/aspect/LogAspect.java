package com.newcoder.toutiao.aspect;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/**
 * Created by 000 on 2017/5/15.
 */
@Aspect
@Component
public class LogAspect {
  private static final Logger logger= LoggerFactory.getLogger(LogAspect.class);
  @Before("execution(* com.newcoder.toutiao.controller.IndexController.*(..))")//在所有的类执行之前进行调用
  public void beforeMethod(JoinPoint joinPoint){
      StringBuilder sb=new StringBuilder();
      for (Object arg:joinPoint.getArgs()){
          sb.append("arg:"+arg.toString()+"|");
      }
      logger.info("before "+sb.toString());
  }
    @After("execution(* com.newcoder.toutiao.controller.IndexController.*(..))")//在所有的类执行之前进行调用
    public void afterMethod(JoinPoint joinPoint){
        logger.info("after "+joinPoint.toLongString());
    }
}

