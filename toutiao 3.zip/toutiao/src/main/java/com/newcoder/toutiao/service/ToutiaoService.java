package com.newcoder.toutiao.service;

import org.springframework.stereotype.Service;

/**
 * Created by 000 on 2017/5/15.
 */
@Service
public class ToutiaoService {
    public String  say(){
    return "This is from ToutiaoService";
    }
}
