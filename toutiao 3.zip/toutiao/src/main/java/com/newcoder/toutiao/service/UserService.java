package com.newcoder.toutiao.service;

import com.newcoder.toutiao.dao.UserDAO;
import com.newcoder.toutiao.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by 000 on 2017/5/23.
 */
@Service
public class UserService {
    @Autowired
    private UserDAO userDAO;
    public User getUser(int id){
       return userDAO.selectById(id);

    }
}
